# 🚀 GitHub Deployment Instructions
# BI Аларма за Аномалии - STOIC 11 Integration

## 📁 Структура на Repository

```
stoic11-business-intelligence/
├── index.html                          # Основен STOIC 11 сайт
├── styles.css                          # Основни стилове
├── script.js                           # Основен JavaScript
├── bi-alarm/                           # BI Аларма приложение
│   ├── index.html                      # BI Аларма главна страница
│   ├── styles.css                      # BI Аларма стилове
│   ├── app.js                          # BI Аларма логика
│   ├── manifest.json                   # PWA манифест
│   ├── icon-192.png                    # PWA икони
│   ├── icon-512.png                    
│   ├── setup.html                      # Setup/welcome страница
│   ├── architecture-diagram.png        # Архитектурна диаграма
│   ├── integration-component.html      # Компонент за интеграция
│   └── README.md                       # BI Аларма документация
└── README.md                           # Основна документация
```

## 🔧 Deployment Стъпки

### 1. Git Setup
```bash
# Clone или navigate to existing repository
cd stoic11-business-intelligence

# Добави новите файлове
git add bi-alarm/
git commit -m "Add BI Аларма за Аномалии mobile app"
git push origin main
```

### 2. GitHub Pages Configuration
- Repository Settings → Pages
- Source: Deploy from a branch
- Branch: main / (root)
- GitHub Pages ще автоматично deploy и двете приложения

### 3. URL Структура След Deployment
```
https://stoicdaniela.github.io/stoic11-business-intelligence/          # Основен сайт
https://stoicdaniela.github.io/stoic11-business-intelligence/bi-alarm/ # BI Аларма
```

## 🔗 Интеграция с Основния Сайт

### Стъпка 1: Добави компонента в главния сайт
Копирай съдържанието от `bi-alarm/integration-component.html` и го постави в основния `index.html` в секцията "Полезни Ресурси".

### Стъпка 2: Навигационни линкове
Добави в navigation menu на основния сайт:
```html
<nav>
    <a href="#home">Начало</a>
    <a href="#services">Услуги</a>
    <a href="#resources">Ресурси</a>
    <a href="bi-alarm/" target="_blank">🚨 BI Аларма</a>
</nav>
```

### Стъпка 3: Footer integration
```html
<footer>
    <div class="footer-links">
        <h4>Инструменти</h4>
        <a href="bi-alarm/">BI Аларма за Аномалии</a>
        <a href="#bi-manager">BI Manager Pro</a>
        <a href="#mobile-portal">Мобилен Портал</a>
    </div>
</footer>
```

## 📱 PWA Installation

### Desktop Browser:
1. Отвори `https://yourdomain/bi-alarm/`
2. Click Install icon в адресната лента
3. Confirm installation

### Mobile:
1. Отвори URL в Safari/Chrome
2. "Add to Home Screen"
3. BI Аларма се инсталира като нативно приложение

## 🔔 Push Notifications Setup

BI Аларма е готова за push notifications. За production ще трябва:

1. **Service Worker** за background processing
2. **Web Push Protocol** integration
3. **Notification API** permissions

## 🧪 Testing Checklist

### Локално тестване:
- [ ] Отвори `bi-alarm/setup.html` в браузър
- [ ] Навигирай до всички секции
- [ ] Тествай създаването на аларми
- [ ] Провери графиките и анимациите
- [ ] Тествай PWA functionality

### Production тестване:
- [ ] GitHub Pages deployment успешен
- [ ] Основен сайт работи нормално
- [ ] BI Аларма достъпна на `/bi-alarm/`
- [ ] PWA installation работи
- [ ] Mobile responsiveness
- [ ] Cross-browser compatibility

## 🔒 Security Considerations

- Всички файлове са статични (HTML/CSS/JS)
- Няма backend dependencies
- PWA manifest е secured
- Icons са optimized

## 📊 Analytics Integration

Добави Google Analytics tracking в `bi-alarm/index.html`:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

## 🚀 Performance Optimization

- Всички изображения са compressed
- CSS/JS са minified ready
- PWA caching prepared
- Mobile-first design

## 📞 Support & Maintenance

**Deployment автор:** MiniMax Agent  
**Дата на создаване:** 2025-10-02  
**Последна актуализация:** 2025-10-02

За въпроси и поддръжка, проверете README.md файловете в съответните папки.

---

## ⚡ Quick Start Commands

```bash
# Clone repository
git clone https://github.com/stoicdaniela/stoic11-business-intelligence.git

# Navigate to project
cd stoic11-business-intelligence

# Open BI Alarm locally
open bi-alarm/setup.html

# Deploy to GitHub Pages
git add .
git commit -m "Update BI Alarm app"
git push origin main
```

GitHub Pages ще автоматично deploy приложенията в рамките на 1-2 минути! 🎉